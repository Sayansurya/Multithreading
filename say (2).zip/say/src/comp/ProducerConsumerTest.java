package comp;

public class ProducerConsumerTest {
	public static void main(String[] args) throws Exception{
		PacketQueue a=new PacketQueue();
		ProducerThread pt=new ProducerThread(a);
		ConsumerThread ct=new ConsumerThread(a);
		pt.start();
		//try{Thread.sleep(10);} catch(Exception e) {}
		//pt.join();
		//ct.join();
		ct.start();
		
				
	}
}
