package comp;

public class ProducerThread  extends Thread{
	PacketQueue q=null;
	ProducerThread(PacketQueue q){
		this.q=q;
	}
	//@override
	public void run() {
		while(true) {
			try {
				q.insert((int)(Math.random()*5000));
				Thread.sleep((long)(Math.random()*5000));
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}
	}
}
