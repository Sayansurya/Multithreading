package comp;

public class PacketQueue {
	
	    private int size = 6;
	    private int front = 0;
	    private int rear = 0;

	    int queu[] = new int[size];


	   public void insert(int stu) throws Exception{
	            if(rear == (front+1)%size){
	                    System.out.println("No space in queue");
	            }
	            else {
	                    queu[front] = stu;
	                    //this.notify();
	                    System.out.println(queu[front]+" inserted in the position "+front);
	                    front = (front+1)%size;
	            }
	            
	    }
	    public void delete() throws Exception{
	            if(front == rear){
	                    System.out.println("Queue is empty");
	            }
	            else {       
	                    System.out.println(queu[rear]+" Is deleted from the position "+rear);
	                    rear = (rear+1)%size;

	            }
	            
	    }
	    
	}

