package comp;

public class ConsumerThread extends Thread{
	PacketQueue q=null;
	public ConsumerThread(PacketQueue q){
		this.q=q;
	}
	public void run() {
		while(true) {
			try {
				q.delete();
				Thread.sleep((long)(Math.random()*5000));
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}
	}
}
